//
//  main.swift
//  Currency Exchange Converter
//
//  Created by Denys on 12/20/24.
//

import Foundation

// Load JSON-file from GitHub
// Decoding JSON file is located in DecodingFromJSON.swift

if let responseData = loadJSONFile(urlString: "https://raw.githubusercontent.com/denysdzhyma/CurrencyExchangeConverter/refs/heads/main/rates.json") {
    let date = responseData.date
    let base = responseData.base
    printResponseData(date: date, base: base)
    printRates(rates: responseData.rates)
} else {
    print("ERROR: Decoding JSON file failed.")
}

currencyFirstOption()


