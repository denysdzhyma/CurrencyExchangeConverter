//
//  CurrencyOptions.swift
//  Currency Exchange Converter
//
//  Created by Denys on 12/21/24.
//

var enterMsgConverter = "How much do you want to convert? (ex.: 365): "
var total = 0.00
var amount = 0.00

func usdEur(rates: CurrencyRates) -> Double {
    total = amount * rates.EUR
    return total
}
